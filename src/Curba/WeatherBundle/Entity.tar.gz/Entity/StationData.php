<?php

namespace Curba\WeatherBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Curba\WeatherBundle\Entity\StationData
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class StationData
{
    /**
     * @var integer $id
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Station")
     * @ORM\JoinColumn(name="station_id", referencedColumnName="id")
     */
    private $station;

    /**
     * @ORM\Column(type="datetime")
     */
    private $data_time;

    /**
     * @ORM\Column(type="decimal")
     */
    private $wind_direction;

    /**
     * @ORM\Column(type="decimal")
     */
    private $wind_speed;

    /**
     * @ORM\Column(type="decimal")
     */
    private $wind_gust;

    /**
     * @ORM\Column(type="decimal")
     */
    private $humidity_in;

    /**
     * @ORM\Column(type="decimal")
     */
    private $humidity_out;

    /**
     * @ORM\Column(type="decimal")
     */
    private $temperature_in;

    /**
     * @ORM\Column(type="decimal")
     */
    private $temperature_out;

    /**
     * @ORM\Column(type="decimal")
     */
    private $bar;

    /**
     * @ORM\Column(type="decimal")
     */
    private $rain;

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set data_time
     *
     * @param datetime $dataTime
     */
    public function setDataTime($dataTime)
    {
        $this->data_time = $dataTime;
    }

    /**
     * Get data_time
     *
     * @return datetime 
     */
    public function getDataTime()
    {
        return $this->data_time;
    }

    /**
     * Set wind_direction
     *
     * @param decimal $windDirection
     */
    public function setWindDirection($windDirection)
    {
        $this->wind_direction = $windDirection;
    }

    /**
     * Get wind_direction
     *
     * @return decimal 
     */
    public function getWindDirection()
    {
        return $this->wind_direction;
    }

    /**
     * Set wind_speed
     *
     * @param decimal $windSpeed
     */
    public function setWindSpeed($windSpeed)
    {
        $this->wind_speed = $windSpeed;
    }

    /**
     * Get wind_speed
     *
     * @return decimal 
     */
    public function getWindSpeed()
    {
        return $this->wind_speed;
    }

    /**
     * Set wind_gust
     *
     * @param decimal $windGust
     */
    public function setWindGust($windGust)
    {
        $this->wind_gust = $windGust;
    }

    /**
     * Get wind_gust
     *
     * @return decimal 
     */
    public function getWindGust()
    {
        return $this->wind_gust;
    }

    /**
     * Set humidity_in
     *
     * @param decimal $humidityIn
     */
    public function setHumidityIn($humidityIn)
    {
        $this->humidity_in = $humidityIn;
    }

    /**
     * Get humidity_in
     *
     * @return decimal 
     */
    public function getHumidityIn()
    {
        return $this->humidity_in;
    }

    /**
     * Set humidity_out
     *
     * @param decimal $humidityOut
     */
    public function setHumidityOut($humidityOut)
    {
        $this->humidity_out = $humidityOut;
    }

    /**
     * Get humidity_out
     *
     * @return decimal 
     */
    public function getHumidityOut()
    {
        return $this->humidity_out;
    }

    /**
     * Set temperature_in
     *
     * @param decimal $temperatureIn
     */
    public function setTemperatureIn($temperatureIn)
    {
        $this->temperature_in = $temperatureIn;
    }

    /**
     * Get temperature_in
     *
     * @return decimal 
     */
    public function getTemperatureIn()
    {
        return $this->temperature_in;
    }

    /**
     * Set temperature_out
     *
     * @param decimal $temperatureOut
     */
    public function setTemperatureOut($temperatureOut)
    {
        $this->temperature_out = $temperatureOut;
    }

    /**
     * Get temperature_out
     *
     * @return decimal 
     */
    public function getTemperatureOut()
    {
        return $this->temperature_out;
    }

    /**
     * Set bar
     *
     * @param decimal $bar
     */
    public function setBar($bar)
    {
        $this->bar = $bar;
    }

    /**
     * Get bar
     *
     * @return decimal 
     */
    public function getBar()
    {
        return $this->bar;
    }

    /**
     * Set rain
     *
     * @param decimal $rain
     */
    public function setRain($rain)
    {
        $this->rain = $rain;
    }

    /**
     * Get rain
     *
     * @return decimal 
     */
    public function getRain()
    {
        return $this->rain;
    }

    /**
     * Set station
     *
     * @param Curba\WeatherBundle\Entity\Station $station
     */
    public function setStation(\Curba\WeatherBundle\Entity\Station $station)
    {
        $this->station = $station;
    }

    /**
     * Get station
     *
     * @return Curba\WeatherBundle\Entity\Station 
     */
    public function getStation()
    {
        return $this->station;
    }
}