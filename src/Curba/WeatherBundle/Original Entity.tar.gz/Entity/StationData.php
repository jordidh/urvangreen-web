<?php

namespace Curba\WeatherBundle\Entity;


/**
 * @orm:Entity
 */
class StationData
{
    /**
     * @orm:Id
     * @orm:Column(type="integer")
     * @orm:GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @orm:ManyToOne(targetEntity="Station")
     * @orm:JoinColumn(name="station_id", referencedColumnName="id")
     */
    private $station;

    /**
     * @orm:Column(type="datetime")
     */
    protected $data_time;

    /**
     * @orm:Column(type="decimal")
     */
    protected $wind_direction;

    /**
     * @orm:Column(type="decimal")
     */
    protected $wind_speed;

    /**
     * @orm:Column(type="decimal")
     */
    protected $wind_gust;

    /**
     * @orm:Column(type="decimal")
     */
    protected $humidity_in;

    /**
     * @orm:Column(type="decimal")
     */
    protected $humidity_out;

    /**
     * @orm:Column(type="decimal")
     */
    protected $temperature_in;

    /**
     * @orm:Column(type="decimal")
     */
    protected $temperature_out;

    /**
     * @orm:Column(type="decimal")
     */
    protected $bar;

    /**
     * @orm:Column(type="decimal")
     */
    protected $rain;
}