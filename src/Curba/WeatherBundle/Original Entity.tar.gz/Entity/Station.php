<?php

namespace Curba\WeatherBundle\Entity;


/**
 * @orm:Entity
 */
class Station
{
    /**
     * @orm:Id
     * @orm:Column(type="integer")
     * @orm:GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @orm:ManyToOne(targetEntity="StationType", inversedBy="stations")
     * @orm:JoinColumn(name="station_type_id", referencedColumnName="id")
     */
    private $station_type;

    /**
     * @orm:Column(type="string", length="255")
     */
    protected $name;

    /**
     * @orm:Column(type="string", length="255", nullable=true)
     */
    protected $description;

    /**
     * @orm:Column(type="decimal")
     */
    protected $longitude;

    /**
     * @orm:Column(type="decimal")
     */
    protected $latitude;

    /**
     * @orm:Column(type="decimal")
     */
    protected $barCorrection;

    /**
     * @orm:Column(type="datetime", name="created_at")
     */
    protected $createdAt;

    /**
     * @orm:Column(type="datetime", name="updated_at")
     */
    protected $updatedAt;

    /**
     * @orm:Column(type="datetime", name="expires_at", nullable=true)
     */
    protected $expiresAt;
    
    /**
     * @orm:OneToMany(targetEntity="StationData", mappedBy="station")
     */
    private $datas;


    public function __construct()
    {
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
        $this->datas = new \Doctrine\Common\Collections\ArrayCollection();
    }

}