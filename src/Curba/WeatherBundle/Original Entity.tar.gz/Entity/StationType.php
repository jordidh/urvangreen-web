<?php

namespace Curba\WeatherBundle\Entity;

use Gedmo\Translatable\Translatable;

/**
 * @orm:Entity
 */
class StationType
{
    /**
     * @orm:Id
     * @orm:Column(type="integer")
     * @orm:GeneratedValue(strategy="IDENTITY")
     */
    protected $id;

    /**
     * @gedmo:Translatable
     * @orm:Column(type="string", length="255", unique=true)
     */
    protected $name;

    /**
     * @gedmo:Translatable
     * @orm:Column(type="string", length="255", nullable=true)
     */
    protected $description;

    /**
     * @orm:Column(type="datetime", name="created_at")
     */
    protected $createdAt;

    /**
     * @orm:Column(type="datetime", name="updated_at")
     */
    protected $updatedAt;

    /**
     * @orm:OneToMany(targetEntity="Station", mappedBy="station_type")
     */
    private $stations;

    /**
     * @gedmo:Locale
     * Used locale to override Translation listener`s locale
     * this is not a mapped field of entity metadata, just a simple property
     */
    private $locale;


    public function __construct()
    {
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
        $this->stations = new \Doctrine\Common\Collections\ArrayCollection();
    }
}