<?php

namespace Curba\GardeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Curba\GardeningBundle\Entity\Crop
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class Crop
{
    /**
     * @var integer $id
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\Column(name="initial_real_date", type="datetime", nullable=false)
     */
    private $initialRealDate;

    /**
     * @ORM\Column(name="initial_planned_date", type="datetime", nullable=false)
     */
    private $initialPlannedDate;

    /**
     * @ORM\Column(name="final_real_date", type="datetime", nullable=true)
     */
    private $finalRealDate;

    /**
     * @ORM\Column(name="final_planned_date", type="datetime", nullable=true)
     */
    private $finalPlannedDate;

    /**
     * @ORM\Column(name="point_x", type="bigint", nullable=false)
     */
    private $pointX;

    /**
     * @ORM\Column(name="point_y", type="bigint", nullable=false)
     */
    private $pointY;

    /**
     * @ORM\Column(name="num_plants", type="bigint", nullable=false)
     */
    private $numPlants;

    /**
     * @ORM\Column(name="created_at", type="datetime", nullable=false)
     */
    private $createdAt;

    /**
     * @ORM\Column(name="updated_at", type="datetime", nullable=false)
     */
    private $updatedAt;

    /**
     * @ORM\ManyToOne(targetEntity="Zone")
     * @ORM\JoinColumn(name="zone_id", referencedColumnName="id")
     */
    private $zone;

    /**
     * @ORM\ManyToOne(targetEntity="CropPeriod")
     * @ORM\JoinColumn(name="crop_period_id", referencedColumnName="id")
     */
    private $initial_crop_period;

    /**
     * @ORM\OneToMany(targetEntity="Plant", mappedBy="crops")
     */
    private $plants;


    public function __construct()
    {
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
        $this->plants = new \Doctrine\Common\Collections\ArrayCollection();
    }
}