<?php

namespace Curba\GardeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Curba\GardeningBundle\Entity\Alert
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class Alert
{
    /**
     * @var integer $id
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\Column(type="datetime", name="created_at")
     */
    private $createdAt;

    /**
     * @ORM\Column(type="datetime", name="updated_at")
     */
    private $updatedAt;

    /**
     * @ORM\Column(type="datetime", name="initial_date")
     */
    private $initialDate;

    /**
     * @ORM\Column(type="datetime", name="final_date")
     */
    private $finalDate;

    /**
     * @ORM\Column(type="datetime", nullable=true)
     */
    private $pospose;

    /**
     * @ORM\ManyToOne(targetEntity="AlertType", inversedBy="alerts")
     * @ORM\JoinColumn(name="alert_type_id", referencedColumnName="id")
     */
    private $alert_type;

    /**
     * @ORM\ManyToOne(targetEntity="Garden", inversedBy="alerts")
     * @ORM\JoinColumn(name="alert_type_id", referencedColumnName="id")
     */
    private $garden;

    public function __construct()
    {
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
    }
}