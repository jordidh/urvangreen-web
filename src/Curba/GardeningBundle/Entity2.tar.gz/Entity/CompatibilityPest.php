<?php

namespace Curba\GardeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Curba\GardeningBundle\Entity\CompatibilityPest
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class CompatibilityPest
{
    /**
     * @var integer $id
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM:Column(name="compatibility", type="integer", nullable=false)
     */
    private $compatibility;

    /**
     * @ORM\Column(type="datetime", name="created_at")
     */
    private $createdAt;

    /**
     * @ORM\Column(type="datetime", name="updated_at")
     */
    private $updatedAt;

    /**
     * @ORM\ManyToOne(targetEntity="Plant")
     * @ORM\JoinColumn(name="plant_a_id", referencedColumnName="id")
     */
    private $plantA;

    /**
     * @ORM\ManyToOne(targetEntity="Plant")
     * @ORM\JoinColumn(name="plant_b_id", referencedColumnName="id")
     */
    private $plantB;

    /**
     * @ORM\ManyToOne(targetEntity="Pest")
     * @ORM\JoinColumn(name="pest_id", referencedColumnName="id")
     */
    private $pest;


    public function __construct()
    {
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
    }
}