<?php

namespace Curba\GardeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Gedmo\Mapping\Annotation as Gedmo;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Curba\GardeningBundle\Entity\Pest
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class Plant implements \Gedmo\Translatable\Translatable
{
    /**
     * @var integer $id
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    
    /**
     * @Gedmo\Translatable
     * @ORM\Column(type="string", length="255", unique=true)
     */
    private $name;

    /**
     * @Gedmo\Translatable
     * @ORM\Column(type="string", length="255", nullable=true)
     */
    private $description;
    
    /**
     * @Gedmo\Translatable
     * @ORM\Column(type="string", length="255", nullable=true)
     */
    private $scientificName;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $productivity;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $widthSpacing;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $heightSpacing;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $soilVolume;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $rootDepth;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $plantHeight;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $seedDepth;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $phMinimum;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $phMaximum;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $temperatureMinimum;

    /**
     * @ORM\Column(type="integer", nullable=false)
     */
    private $temperatureMaximum;

    /**
     * @ORM\Column(type="datetime", name="created_at")
     */
    private $createdAt;

    /**
     * @ORM\Column(type="datetime", name="updated_at")
     */
    private $updatedAt;

    /**
     * @ORM\ManyToOne(targetEntity="FertilizerType")
     * @ORM\JoinColumn(name="fertilizer_type_id", referencedColumnName="id")
     */
    private $fertilizerType;

    /**
     * @ORM\ManyToOne(targetEntity="LifeCicleType")
     * @ORM\JoinColumn(name="life_cicle_type_id", referencedColumnName="id")
     */
    private $lifeCicleType;

    /**
     * @ORM\ManyToOne(targetEntity="PlantFamily")
     * @ORM\JoinColumn(name="plant_family_id", referencedColumnName="id")
     */
    private $plantFamily;

    /**
     * @ORM\ManyToOne(targetEntity="ClimateType")
     * @ORM\JoinColumn(name="climate_type_id", referencedColumnName="id")
     */
    private $climateType;

    /**
     * @ORM\ManyToOne(targetEntity="SoilType")
     * @ORM\JoinColumn(name="soil_type_id", referencedColumnName="id")
     */
    private $soilType;

    /**
     * @ORM\ManyToOne(targetEntity="IrrigationType")
     * @ORM\JoinColumn(name="irrigation_type_id", referencedColumnName="id")
     */
    private $irrigationType;

    /**
     * @ORM\ManyToOne(targetEntity="FrostResistanceType")
     * @ORM\JoinColumn(name="frost_resistance_type_id", referencedColumnName="id")
     */
    private $frostResistanceType;

    /**
     * @ORM\ManyToOne(targetEntity="SalinityToleranceType")
     * @ORM\JoinColumn(name="salinity_tolerance_type_id", referencedColumnName="id")
     */
    private $salinityToleranceType;

    /**
     * @ORM\ManyToOne(targetEntity="PlantCare")
     * @ORM\JoinColumn(name="plant_care_id", referencedColumnName="id")
     */
    private $plantCare;

    /**
     * @ORM\ManyToOne(targetEntity="ActionType")
     * @ORM\JoinColumn(name="action_type_id", referencedColumnName="id")
     */
    private $actionType;
    
    /**
     * @ORM\OneToMany(targetEntity="Crop", mappedBy="plant")
     */
    private $crops;

    /**
     * @ORM\OneToMany(targetEntity="CropPeriod", mappedBy="plant")
     */
    private $cropPeriods;
    
    /**
     * @ManyToMany(targetEntity="Pest", inversedBy="plants")
     * @JoinTable(name="plants_pests")
     */
    private $pests;
    
    public function __construct()
    {
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
        $this->crops = new \Doctrine\Common\Collections\ArrayCollection();
        $this->cropPeriods = new \Doctrine\Common\Collections\ArrayCollection();
        $this->pests = new \Doctrine\Common\Collections\ArrayCollection();
    }
}