<?php

namespace Curba\GardeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Curba\GardeningBundle\Entity\Zone
 *
 * @ORM\Table()
 * @ORM\Entity
 */
class Zone
{
    /**
     * @var integer $id
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;
    
    /**
     * @ORM\Column(type="string", length="255", unique=true)
     */
    private $name;

    /**
     * @ORM\Column(type="string", length="255", nullable=true)
     */
    private $description;

    /**
     * @ORM\Column(name="initial_point_x", type="bigint", nullable=false)
     */
    private $initialPointX;

    /**
     * @ORM\Column(name="initial_point_y", type="bigint", nullable=false)
     */
    private $initialPointY;

    /**
     * @ORM\Column(name="final_point_x", type="bigint", nullable=false)
     */
    private $finalPointX;

    /**
     * @ORM\Column(name="final_point_y", type="bigint", nullable=false)
     */
    private $finalPointY;

    /**
     * @ORM\Column(name="depth", type="bigint", nullable=false)
     */
    private $depth;

    /**
     * @ORM\Column(type="datetime", name="created_at")
     */
    private $createdAt;

    /**
     * @ORM\Column(type="datetime", name="updated_at")
     */
    private $updatedAt;

    /**
     * @ORM\ManyToOne(targetEntity="Garden")
     * @ORM\JoinColumn(name="garden_id", referencedColumnName="id")
     */
    private $garden;

    /**
     * @ORM\ManyToOne(targetEntity="ZoneType")
     * @ORM\JoinColumn(name="zone_type_id", referencedColumnName="id")
     */
    private $zone_type;

    /**
     * @ORM\OneToMany(targetEntity="Crop", mappedBy="zone")
     */
    private $crops;


    public function __construct()
    {
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
        $this->crops = new \Doctrine\Common\Collections\ArrayCollection();
    }
}